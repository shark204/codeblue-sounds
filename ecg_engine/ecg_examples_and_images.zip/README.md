# Code Blue ECG Reference Atlas & Examples Pack

- Total ECG Conditions Covered: 20
- Total Numeric Clinical Examples: 101 (>= 5 per condition)
- Total Real Extracted ECG Images: 100 (>= 5 per condition)
- Automated Engine Validation: 101/101 PASSED
- Dynamic JSON Threshold Reactivity Test: PASSED

## Quick Start
1. Place `ecg_criteria.json` and `ecg_rules.py` in the same folder.
2. Edit any numeric threshold in `ecg_criteria.json` — `ecg_rules.py` automatically picks it up.
3. Run: `python3 ecg_rules.py --input sample_ecg.json --lang ar`
